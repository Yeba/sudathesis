# SUDA硕博学位论文模版

基于[科大模板](https://github.com/ustctug/ustcthesis/)v3.3.4制作，替换了封面。

win，mac，overleaf三端兼容。

使用前需设置xelatex编译。
